package carddeck.client.classes;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

/*Task 2: import neccessary user defined classes if needed*/
import carddeck.service.classes.CardValue;
import carddeck.service.classes.Card;
import carddeck.service.classes.CardSign;

class Ninecards{
	Card [] yourHand = new Card[9]; //player's hand, provided in the text file
	Card [] houseHand = new Card[9]; //house's hand, randomly generated

    private void generateHouseHand(){//method to randomly generate the cards for the house
		
		/*Task 5: Add code to generate the cards for the house*/
		for(int i = 0; i<= houseHand.length-1; i++){
			houseHand[i] = new Card(CardSign.values()[(int)(Math.random()*4+0)], CardValue.values()[(int)(Math.random()*12+0)]);
		}
	}
	private int getScore(){
		
		/*Task 6: compare the user's hand with the randomly genereted hand of the house*/
		int score = 0;
		for(int i = 0; i <= 8; i++){
			score += yourHand[i].compareCards(houseHand[i]);
		}
		return score;
	}	
	public static void main(String []args){
	//arg[0]: file containing your hand
		Ninecards game=new Ninecards();
		//read the the files from text files
		int counter=0;
		Card aCard;
		Scanner scan;
		String str;
		try {
			File myFile=new File("hand.txt");
            scan=new Scanner(myFile);//each line has the format title:genre:author-name-1,author-name-2..authorname-m
			while(scan.hasNextLine()){
				str=scan.nextLine();				
				String []tok=str.split(":");
				/*Task 4: insert the information about the user's cards read from the text file, into the class array */
				game.yourHand[counter] = new Card(CardSign.valueOf(tok[0]), CardValue.valueOf(tok[1]));
				counter++;
			}
		//lets play Nine Cards!!
		//User interactive part
		String option1;
		scan = new Scanner(System.in);
		int score;
		while(true){
			System.out.println("Select an option:");
			System.out.println("Type \"P\" to play a round of Nine Cards");			
			System.out.println("Type \"Q\" to Quit");
			option1=scan.nextLine();
			
			switch (option1) {								 
				case "P":   /*generate the cards for the house*/
							game.generateHouseHand();
							/*Compare the house cards with the cards of the user*/
				            score=game.getScore();
							for(int i = 0; i<= 8; i++){
								System.out.println("Comparing my "+ game.yourHand[i].getSign()+":"+game.yourHand[i].getValue()+" with the house's "+game.houseHand[i].getSign()+":"+game.houseHand[i].getValue());
								if(game.yourHand[i].compareCards(game.houseHand[i])>0)
									System.out.println("My card wins");
								if(game.yourHand[i].compareCards(game.houseHand[i])==0)
									System.out.println("Draw");
								else
									System.out.println("House's card wins");
							}
							if(score < 0)
								System.out.println("House Wins :-(");
							else if (score == 0)
								System.out.println("Its a draw");
							else if (score > 0)
								System.out.println("Congrats You win !!");
							else
								System.out.println("Somethings wrong!");
							break;
				
				case "Q":   System.out.println("Quitting program");
							System.exit(0);
							
				default:	System.out.println("Wrong option! Try again");
							break;
			
			}
			
		}					
		}catch(IOException ioe){ 
			System.out.println("The file can not be read");
		}catch(IllegalArgumentException ia){ 
            System.out.println(ia.getMessage());
		} catch(NullPointerException np){
			System.out.println(np.getMessage());
		}
	}	

}